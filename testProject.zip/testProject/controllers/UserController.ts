import User from '../models/User';
import userInterface from '../interface/controllers/userInterface';

class UserController implements userInterface {
    public static getAllUsers() {
        return new Promise((resolve, reject) => {
            User.find({deleted: false}).then((data) => {
                resolve(data);
            }).catch((err) => {
                reject('Internal Error');
            });
        });
    }

    public static saveUser(body: Object) {
        return new Promise((resolve, reject) => {
            User.findOne({email: new RegExp(body.email, 'i'), deleted: false})
            .then((data) => {
                return data;
            })
            .then((exist) => {
                if (exist) {
                    reject('Email already exist, Please try again');    
                } else {
                    new User({ 
                        name: body.name, 
                        email: body.email, 
                        phone: body.phone
                    }).save((err, data) => {
                        if (!err)
                            resolve(data);
                        else 
                            reject('Internal Error');
                    });
                }
            }).catch((err) => {
                reject('Internal Error');
            });
        });
    }
  
    public static updateUser(id:string, body: Object) {
        return new Promise((resolve, reject) => {
            User.findOne({_id: { $ne: id }, email: new RegExp(body.email, 'i'), deleted: false})
            .then((data) => {
                return data;
            })
            .then((exist) => {
                if (exist) {
                    reject('Email already exist, Please try again');    
                } else {
                   return User.findOne({_id: id, deleted: false});
                }
            })
            .then((userData) => {
                if (!userData) {
                    reject('User not found');  
                    return;
                }
                userData.name = body.name;
                userData.email = body.email;
                userData.phone = body.phone;
                userData.save((err, data) => {
                    if (!err)
                        resolve(data);
                    else 
                        reject('Internal Error');
                });
            }).catch((err) => {
                console.log(err, 'error');
                reject('Internal Error');
            });
        });
    }    

    public static getUserById(id:string) {
        return new Promise((resolve, reject) => {
            User.findOne({_id: id}).then((data) => {
                resolve(data);
            }).catch((err) => {
                reject('Internal Error');
            });
        });
    }

    public static deleteUser(id:string) {
        return new Promise((resolve, reject) => {
            User.findOne({_id: id})
            .then((data) => {
                if(!data) {
                    reject('User not found');  
                } else {
                    data.deleted = true;
                    data.save((err, savedUser) => {
                        if (!err)
                            resolve(savedUser);
                        else 
                            reject('Internal Error');
                    });
                }
            }).catch((err) => {
                reject('Internal Error');
            });
        });
    }

}

export default UserController;