import { Router, Request, Response, NextFunction } from 'express';
import User from '../models/User';
import UserController from '../controllers/UserController';

class UserRouter {
    router: Router;

    constructor() {
        this.router = Router();
        this.routes();
    }
    public GetUsers (req: Request, res: Response): void {
        UserController.getAllUsers().then((data) => {
            res.json({
                status: 200,
                data: data
            });
        }).catch((err) => {
            res.json({
                status: 500,
                data: err
            });
        });
    }

    public SaveUser (req: Request, res: Response): void {
        UserController.saveUser(req.body).then((data) => {
            res.json({
                status: 200,
                message: 'User saved successfully',
                data: data
            });
        }).catch((err) => {
            res.json({
                status: 500,
                message: err
            });
        });
    }

    public UpdateUser (req: Request, res: Response): void {
        UserController.updateUser(req.params.id, req.body).then((data) => {
            res.json({
                status: 200,
                message: 'User updated successfully',
                data: data
            });
        }).catch((err) => {
            res.json({
                status: 500,
                message: err
            });
        });
    }    

    public GetUserById (req: Request, res: Response): void {
        UserController.getUserById(req.params.id).then((data) => {
            res.json({
                status: 200,
                data: data
            });
        }).catch((err) => {
            res.json({
                status: 500,
                message: err
            });
        });
    }

    public DeleteUser (req: Request, res: Response): void {
        UserController.deleteUser(req.params.id).then((data) => {
            res.json({
                status: 200,
                message: 'User deleted successfully',
                data: data
            });
        }).catch((err) => {
            res.json({
                status: 500,
                message: err
            });
        });
    }    

    routes() {
        this.router.get('/', this.GetUsers);
        this.router.post('/', this.SaveUser);
        this.router.put('/:id', this.UpdateUser);
        this.router.delete('/:id', this.DeleteUser);
        this.router.get('/byId/:id', this.GetUserById);
    }
}

//export
const userRoutes = new UserRouter();
userRoutes.routes();

export default userRoutes.router;
