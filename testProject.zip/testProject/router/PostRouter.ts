import { Router, Request, Response, NextFunction } from 'express';
import Post from '../models/Post';

class PostRouter {
    router: Router;

    constructor() {
        this.router = Router();
        this.routes();
    }
    public GetPosts (req: Request, res: Response): void {
        Post.find({}).then((data) => {
            res.json({
                status: 200,
                data: data
            });
        }).catch((err) => {
            res.json({
                status: 500,
                data: err
            });
        });
    }

    public SavePost (req: Request, res: Response): void {
        new Post({
            title: req.body.title,
            content: req.body.content,
            slug: req.body.title.replace(new RegExp(' ', 'g'), '_')
        }).save((err, data) => {
            if (err) {
                res.json({
                    status: 500,
                    data: err
                });
            } else {
                res.json({
                    status: 200,
                    data: data
                });
            }
        });
    }

    routes() {
        this.router.get('/', this.GetPosts);
        this.router.post('/', this.SavePost);
    }
}

//export
const postRoutes = new PostRouter();
postRoutes.routes();

export default postRoutes.router;
