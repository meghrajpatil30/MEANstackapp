
export module userInterface {
     interface userInterface {
        saveUser(body: Object);
    }
}